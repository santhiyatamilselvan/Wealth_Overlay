{% macro add_audit_columns() %}
    , current_timestamp() as loaded_at
    , '{{ invocation_id }}' as batch_id
{% endmacro %}