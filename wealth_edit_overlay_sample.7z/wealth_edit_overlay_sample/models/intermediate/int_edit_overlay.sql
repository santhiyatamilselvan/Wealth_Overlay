with ranked_txn as (
    select *,
           row_number() over (partition by account_id order by transaction_date desc) as rn
    from {{ ref('stg_transactions') }}
)
select *
from ranked_txn
where rn = 1