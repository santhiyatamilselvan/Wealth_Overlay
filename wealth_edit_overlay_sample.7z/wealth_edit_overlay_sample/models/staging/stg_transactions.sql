select
    account_id,
    transaction_amount,
    transaction_date
from {{ source('wealth', 'transactions') }}